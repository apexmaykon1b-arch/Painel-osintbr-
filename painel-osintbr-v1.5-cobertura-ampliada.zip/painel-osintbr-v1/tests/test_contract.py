import unittest
from core.store import create_investigation, save_finding, list_findings, list_investigations, connect, now_iso, new_id

class ContractTests(unittest.TestCase):
    def test_finding_contract_and_storage(self):
        ident = create_investigation('Teste automatizado')
        finding = {'id':new_id('f'),'type':'domain','value':'example.com','detail':'Teste local','status':'info','module':'test','ts':now_iso(),'source':'teste','confidence':'teste'}
        save_finding(ident, finding)
        results = list_findings(ident)
        self.assertTrue(any(x['id'] == finding['id'] for x in results))
        required = {'id','type','value','detail','status','module','ts','source','confidence'}
        self.assertTrue(required.issubset(set(results[0].keys())))
        conn = connect(); conn.execute('DELETE FROM investigations WHERE id=?',(ident,)); conn.commit(); conn.close()

if __name__ == '__main__': unittest.main()
