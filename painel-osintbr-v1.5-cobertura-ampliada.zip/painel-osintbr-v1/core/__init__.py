"""Núcleo do Painel OSINT BR."""
