# pw 🔎 Painel OSINT BR — Web V1 + núcleo Python para Termux

O projeto contém a interface web original e um núcleo Python local ampliado. O estilo é inspirado em painéis OSINT escuros, mas mantém marca própria **pw 🔎 Painel OSINT BR**.

## Módulos Python
- **Investigações:** SQLite local, descobertas padronizadas, listagem e exportação JSON.
- **DNS:** registros A, AAAA, MX, NS, TXT e CNAME via DNS-over-HTTPS público.
- **HTTP(S):** status e cabeçalhos selecionados; não executa JavaScript.
- **Usuários:** verifica URLs públicas de plataformas conhecidas; respostas 200 são apenas indícios e exigem conferência manual.
- **E-mail:** validação sintática + DNS/MX; não verifica existência da caixa postal.
- **Telefone:** normalização local; não identifica titular nem confirma atividade.
- **IP público:** consulta opcional a dados públicos via ipapi.co; geolocalização é aproximada.
- **Portas TCP:** teste limitado a 18 portas comuns, com timeout curto e confirmação explícita de autorização; no máximo 30 portas por chamada.
- **Arquivos:** tamanho, MIME estimado e SHA-256 calculado localmente, sem alterar o original.

## Iniciar no Termux
Na pasta extraída `painel-osintbr-v1`:

```bash
pkg update
pkg install python
python main.py
```

Não é necessário `pip install`: o núcleo usa a biblioteca padrão do Python. É necessária conexão à internet para consultas DNS/HTTP, usernames e IP público.

## Como usar
1. Escolha `1` para criar uma investigação.
2. Escolha um módulo (opções 3–10) e selecione a investigação quando solicitado.
3. Examine cada resultado, a fonte e as limitações.
4. Confirme se quer salvar os resultados na investigação.
5. Use `11` para rever descobertas e `12` para exportar JSON.

## Interface web
Abra `index.html` em um navegador ou publique-o em hospedagem estática. Os dados web continuam no `localStorage` com a chave `osintbr_v1`. A interface web e o banco SQLite do núcleo Python **ainda não sincronizam automaticamente**.

## Contrato de finding
Cada descoberta segue `id`, `type`, `value`, `detail`, `status`, `module`, `ts`, `source` e `confidence`. Status possíveis incluem `confirmado`, `indicio`, `inconclusivo`, `info` e `erro`. Uma ausência de resposta não é prova de inexistência.

## Segurança e limites
- Use consultas ativas e testes de portas apenas em sistemas próprios ou com autorização explícita.
- O scanner não faz exploração, brute force, evasão, captura de credenciais ou varredura ampla de intervalos.
- Uma URL de username que responde HTTP 200 não prova que um perfil existe nem que pertence a uma pessoa.
- Dados de IP não revelam necessariamente a localização de um indivíduo.
- O núcleo não implementa sincronização web/SQLite nem promete detectar todos os perfis em todas as plataformas.

## Testes
Na raiz do projeto:

```bash
python -m unittest discover -s tests -v
```


## Cobertura ampliada (v1.4+)

- Username: catálogo ampliado de URLs públicas, incluindo redes sociais, comunicação, desenvolvimento, estudo e trabalho. Uma resposta HTTP 200 é apenas indício; páginas genéricas, bloqueios e redirecionamentos podem gerar falsos positivos.
- E-mail: validação de sintaxe + consulta MX + catálogo de páginas oficiais de ajuda/recuperação. O catálogo não verifica automaticamente se existe uma conta e não deve ser apresentado como Holehe real.
- Portas TCP: padrão de 100 portas selecionadas, com confirmação explícita de autorização no CLI. `confirmado` significa conexão TCP aceita naquele instante; `inconclusivo` não diferencia com certeza firewall, filtro e porta fechada.
- A legenda dos status aparece antes dos resultados. O contrato de findings e a interface `index.html` foram preservados.

### Status

- `confirmado`: a fonte confirmou o fato específico descrito, não a identidade de uma pessoa.
- `indicio`: sinal que precisa de confirmação independente.
- `info`: contexto ou validação que não confirma existência de conta.
- `inconclusivo`: não foi possível concluir por bloqueio, ausência de resposta ou evidência insuficiente.
- `erro`: a consulta falhou; não significa que o dado não exista.

Antes de publicar, revise links e termos de cada serviço. Sites mudam rotas e podem impor limites. Não inclua dados pessoais reais nos exemplos, issues ou relatórios públicos.
