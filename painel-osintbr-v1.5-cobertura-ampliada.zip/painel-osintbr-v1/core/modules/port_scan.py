"""Scanner TCP simples e limitado a portas comuns; use somente com autorização."""
import socket, ipaddress
from ..store import new_id, now_iso
COMMON_PORTS={21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',80:'HTTP',110:'POP3',111:'RPCbind',135:'MS RPC',139:'NetBIOS',143:'IMAP',161:'SNMP',194:'IRC',389:'LDAP',443:'HTTPS',445:'SMB',465:'SMTPS',514:'Syslog',587:'SMTP submission',631:'IPP',636:'LDAPS',873:'rsync',993:'IMAPS',995:'POP3S',1080:'SOCKS',1194:'OpenVPN',1433:'MS SQL',1521:'Oracle',1723:'PPTP',1883:'MQTT',2049:'NFS',2181:'ZooKeeper',2375:'Docker API',2376:'Docker TLS',3000:'Dev server',3128:'Proxy',3306:'MySQL',3389:'RDP',3690:'Subversion',4444:'Metasploit/common app',5000:'App server',5432:'PostgreSQL',5672:'AMQP',5900:'VNC',5985:'WinRM HTTP',5986:'WinRM HTTPS',6379:'Redis',6443:'Kubernetes API',6667:'IRC',7001:'WebLogic',8000:'HTTP-alt',8008:'HTTP-alt',8080:'HTTP-alt',8081:'HTTP-alt',8088:'HTTP-alt',8443:'HTTPS-alt',8888:'HTTP-alt',9000:'App server',9090:'Web console',9200:'Elasticsearch',9300:'Elasticsearch cluster',9418:'Git',11211:'Memcached',27017:'MongoDB'}
# First 100 common TCP ports; remaining ports in this list are included in the scan by default.
DEFAULT_PORTS = sorted(set(range(1, 101)) - {1,2,3,4,6,7,9,13,17,19} | {443,445,587,993,995,1433,3306,3389,5432,8080})
def scan_ports(host, ports=None, timeout=0.7):
    host=host.strip()
    if not host or any(c in host for c in '/?#@ '): raise ValueError('Informe apenas um hostname ou IP, sem URL/caminho.')
    selected=ports or DEFAULT_PORTS
    if len(selected)>100 or any(not isinstance(p,int) or not 1<=p<=65535 for p in selected): raise ValueError('Use no máximo 100 portas válidas por execução.')
    try: resolved=socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)[0][4][0]
    except OSError as e: raise ValueError(f'Não foi possível resolver o alvo: {e}')
    # Require literal IP and explicit caller confirmation in CLI; module itself remains bounded.
    results=[]
    for port in selected:
        s=socket.socket(socket.AF_INET6 if ':' in resolved else socket.AF_INET, socket.SOCK_STREAM); s.settimeout(timeout)
        try:
            address=(resolved,port,0,0) if ':' in resolved else (resolved,port)
            code=s.connect_ex(address)
            is_open=code==0
            service=COMMON_PORTS.get(port, 'serviço desconhecido')
            detail=f'TCP/{port} ({service}): ' + ('conexão aceita (porta aberta).' if is_open else 'conexão não estabelecida; pode estar fechada ou filtrada.')
            results.append({'id':new_id('f'),'type':'port','value':f'{host}:{port}','detail':detail, 'status':'confirmado' if is_open else 'inconclusivo','module':'port_scan','ts':now_iso(),'source':f'tentativa TCP direta em {resolved}:{port}','confidence':'Confirma que a conexão foi aceita neste momento.' if is_open else 'Não distingue com certeza porta fechada de filtragem/firewall.'})
        finally: s.close()
    return results
