"""Checagem prudente de URLs públicas de perfis; não identifica pessoas."""
import urllib.request
import urllib.error
from urllib.parse import quote
from ..store import new_id, now_iso

# ~20 redes / plataformas públicas
PLATFORMS = {
    "GitHub": "https://github.com/{user}", "GitLab": "https://gitlab.com/{user}", "Codeberg": "https://codeberg.org/{user}",
    "Reddit": "https://www.reddit.com/user/{user}/", "X": "https://x.com/{user}", "Instagram": "https://www.instagram.com/{user}/",
    "TikTok": "https://www.tiktok.com/@{user}", "YouTube": "https://www.youtube.com/@{user}", "Twitch": "https://www.twitch.tv/{user}",
    "Medium": "https://medium.com/@{user}", "Dev.to": "https://dev.to/{user}", "Pinterest": "https://www.pinterest.com/{user}/",
    "Telegram": "https://t.me/{user}", "Keybase": "https://keybase.io/{user}", "About.me": "https://about.me/{user}",
    "Linktree": "https://linktr.ee/{user}", "Hacker News": "https://news.ycombinator.com/user?id={user}", "SoundCloud": "https://soundcloud.com/{user}",
    "Vimeo": "https://vimeo.com/{user}", "Patreon": "https://www.patreon.com/{user}", "Flickr": "https://www.flickr.com/people/{user}/",
    "Tumblr": "https://{user}.tumblr.com", "Mastodon.social": "https://mastodon.social/@{user}", "Bluesky": "https://bsky.app/profile/{user}.bsky.social",
    "Threads": "https://www.threads.net/@{user}", "Facebook": "https://www.facebook.com/{user}", "Snapchat": "https://www.snapchat.com/add/{user}",
    "Discord (perfil público)": "https://discord.com/users/{user}", "Steam": "https://steamcommunity.com/id/{user}", "Xbox": "https://xboxgamertag.com/search/{user}",
    "PlayStation": "https://psnprofiles.com/{user}", "Roblox": "https://www.roblox.com/user.aspx?username={user}", "Minecraft NameMC": "https://namemc.com/profile/{user}",
    "Chess.com": "https://www.chess.com/member/{user}", "Lichess": "https://lichess.org/@/{user}", "Strava": "https://www.strava.com/athletes/{user}",
    "Komoot": "https://www.komoot.com/user/{user}", "ResearchGate": "https://www.researchgate.net/profile/{user}", "ORCID": "https://orcid.org/{user}",
    "Google Scholar": "https://scholar.google.com/citations?user={user}", "Kaggle": "https://www.kaggle.com/{user}", "Hugging Face": "https://huggingface.co/{user}",
    "Docker Hub": "https://hub.docker.com/u/{user}", " npm ": "https://www.npmjs.com/~{user}", "PyPI": "https://pypi.org/user/{user}/", "Replit": "https://replit.com/@{user}",
    "Glitch": "https://glitch.com/@{user}", "CodePen": "https://codepen.io/{user}", "JSFiddle": "https://jsfiddle.net/user/{user}/", "Behance": "https://www.behance.net/{user}",
    "Dribbble": "https://dribbble.com/{user}", "DeviantArt": "https://www.deviantart.com/{user}", "ArtStation": "https://www.artstation.com/{user}",
    "Pixiv": "https://www.pixiv.net/en/users/{user}", "Kofi": "https://ko-fi.com/{user}", "Buy Me a Coffee": "https://www.buymeacoffee.com/{user}",
    "Substack": "https://{user}.substack.com", "WordPress": "https://{user}.wordpress.com", "Blogger": "https://{user}.blogspot.com", "Wattpad": "https://www.wattpad.com/user/{user}",
    "Goodreads": "https://www.goodreads.com/{user}", "Letterboxd": "https://letterboxd.com/{user}/", "IMDb": "https://www.imdb.com/user/{user}/", "Last.fm": "https://www.last.fm/user/{user}",
    "Bandcamp": "https://{user}.bandcamp.com", "Mixcloud": "https://www.mixcloud.com/{user}/", "OpenStreetMap": "https://www.openstreetmap.org/user/{user}",
    "Instructables": "https://www.instructables.com/member/{user}/", "Scratch": "https://scratch.mit.edu/users/{user}/", "Duolingo": "https://www.duolingo.com/profile/{user}",
    "Khan Academy": "https://www.khanacademy.org/profile/{user}", "Coursera": "https://www.coursera.org/user/{user}", "TryHackMe": "https://tryhackme.com/p/{user}",
    "Hack The Box": "https://app.hackthebox.com/profile/{user}", "Root-Me": "https://www.root-me.org/{user}", "Keybase": "https://keybase.io/{user}",
    "Product Hunt": "https://www.producthunt.com/@{user}", "Indie Hackers": "https://www.indiehackers.com/{user}", "AngelList/Wellfound": "https://wellfound.com/u/{user}",
    "Gravatar": "https://gravatar.com/{user}", "Internet Archive": "https://archive.org/details/@{user}", "Open Collective": "https://opencollective.com/{user}",
    "Gitee": "https://gitee.com/{user}", "Bitbucket": "https://bitbucket.org/{user}/", "Launchpad": "https://launchpad.net/~{user}", "SourceForge": "https://sourceforge.net/u/{user}/profile/",
    "Telegram Web": "https://t.me/{user}", "TikTok web": "https://www.tiktok.com/@{user}", "Instagram web": "https://www.instagram.com/{user}/",
}


def lookup_username(username, timeout=6, platforms=None):
    username = username.strip().lstrip("@")
    if not username or len(username) > 80 or any(c.isspace() for c in username):
        raise ValueError("Informe um nome de usuário válido, sem espaços.")
    chosen = platforms or list(PLATFORMS)
    out = []
    for platform in chosen:
        if platform not in PLATFORMS:
            continue
        url = PLATFORMS[platform].format(user=quote(username, safe=""))
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; OSINTBR/1.1)",
                "Accept": "text/html",
            },
        )
        status = "inconclusivo"
        http_code = None
        detail = "Consulta não classificável apenas pelo HTTP."
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                http_code = r.status
            if http_code == 200:
                status = "indicio"
                detail = (
                    "HTTP 200 — possível perfil ou página genérica; confirme manualmente."
                )
            else:
                detail = f"HTTP {http_code}; não confirma perfil."
        except urllib.error.HTTPError as e:
            http_code = e.code
            if e.code == 404:
                status = "info"
                detail = "HTTP 404 nesta consulta; não prova inexistência definitiva."
            else:
                detail = f"HTTP {e.code}; inconclusivo."
        except Exception as e:
            detail = f"Falha ({type(e).__name__}): bloqueio, timeout ou rede."
        out.append(
            {
                "id": new_id("f"),
                "type": "username",
                "value": username,
                "detail": f"{platform}: {detail}",
                "status": status,
                "module": "username_lookup",
                "ts": now_iso(),
                "source": url,
                "platform": platform,
                "http": http_code,
                "confidence": "Baixa a moderada — verificar no navegador.",
            }
        )
    return out
