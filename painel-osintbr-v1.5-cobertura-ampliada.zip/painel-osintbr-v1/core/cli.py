"""Interface simples do pw 🔎 OSINT BR para Termux/Linux."""
import json
from pathlib import Path
from datetime import datetime, timezone
from .modules.dns_lookup import lookup as dns_lookup
from .modules.http_check import check_url
from .modules.username_lookup import lookup_username
from .modules.email_check import check_email
from .modules.phone_check import check_phone
from .modules.port_scan import scan_ports, COMMON_PORTS
from .modules.file_analysis import analyze_file
from .modules.ip_lookup import lookup_ip
from .modules.extractor import extract_from_text

ROOT = Path(__file__).resolve().parent.parent
HISTORY = ROOT / 'data' / 'resultados.json'

# Cores bandeira do Brasil (ANSI)
R = '\033[0m'
G = '\033[1;32m'      # verde
Y = '\033[1;33m'      # amarelo
B = '\033[1;34m'      # azul
W = '\033[1;37m'
DIM = '\033[2m'
RED = '\033[1;31m'

# Onça (rosto em blocos) + título — tema BR
ONCA = r'''
{G}            ▄▄████▄▄
{G}         ▄███████████▄
{Y}        ██{G}█{Y}██{G}█{Y}██{G}█{Y}██{G}█{Y}██
{Y}       ██{W}▄{Y}█{W}▀{Y}██{W}▄{Y}█{W}▀{Y}███
{Y}       ███{B}▀▀{Y}████{B}▀▀{Y}███
{Y}        ██▄{W}▄▄▄▄▄▄{Y}▄██
{Y}         ▀████████▀
{G}           ▀████▀{R}
'''

BANNER_TITLE = f'''
{G}╔══════════════════════════════════════╗
{G}║{Y}     🔎  PAINEL OSINT BR  🇧🇷         {G}║
{G}║{B}        onça · fontes abertas         {G}║
{G}╚══════════════════════════════════════╝{R}
'''

MENU = [
 ('1', 'E-mail', 'Formato + MX'),
 ('2', 'Username', 'Perfis públicos'),
 ('3', 'Telefone', 'Normalizar número'),
 ('4', 'DNS', 'Registros do domínio'),
 ('5', 'HTTP(S)', 'Status + cabeçalhos'),
 ('6', 'IP público', 'Dados aproximados'),
 ('7', 'Portas TCP', 'Somente com autorização'),
 ('8', 'Arquivo', 'Metadados + SHA-256'),
 ('9', 'Resultados', 'Histórico + correlações'),
 ('10', 'Exportar JSON', 'Salvar histórico em arquivo'),
 ('11', 'Extrator Intel', 'E-mail, IP, URL, hash, CPF…'),
 ('12', 'Ajuda', 'Fontes e limitações'),
]

import sys
import time

def print_banner():
    # ONCA usa placeholders {G}{Y}{B}{W}{R}
    art = ONCA.format(G=G, Y=Y, B=B, W=W, R=R)
    print(art)
    print(BANNER_TITLE)

def load_history():
    try:
        data=json.loads(HISTORY.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except (OSError, ValueError): return []

def save_history(findings):
    HISTORY.parent.mkdir(parents=True,exist_ok=True)
    old=load_history()
    old.extend(findings)
    HISTORY.write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding='utf-8')

def _type_line(text, delay=0.012):
    """Imprime texto com efeito letra a letra (rápido)."""
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        if ch != '\n':
            time.sleep(delay)
    if not text.endswith('\n'):
        print()

def _step(msg, color=Y, pause=0.35):
    print(f'{color}  → {msg}{R}')
    time.sleep(pause)

def _status_color(status):
    s = (status or 'info').lower()
    if s in ('confirmado', 'ok', 'indicio'):
        return G
    if s in ('erro', 'error'):
        return RED
    if s in ('inconclusivo', 'warn'):
        return Y
    return B  # azul — info

def _short_detail(f):
    """Uma linha curta: prioriza plataforma + valor + status HTTP se houver."""
    plat = f.get('platform') or f.get('group') or f.get('type') or ''
    val = str(f.get('value') or '')
    src = f.get('source') or ''
    http = f.get('http')
    det = str(f.get('detail') or '')
    # Evita textos longos de limitação
    if len(det) > 90:
        det = det[:87] + '...'
    parts = []
    if plat:
        parts.append(str(plat))
    if http is not None:
        parts.append(f'HTTP {http}')
    elif src and src.startswith('http'):
        parts.append(src if len(src) < 50 else src[:47] + '...')
    elif det:
        parts.append(det)
    return ' · '.join(parts) if parts else val

def show_findings(findings, animate=True):
    if not findings:
        print(f'{Y}  (sem dados){R}')
        return

    if animate:
        _step('verificando se é compatível...', Y, 0.28)
        _step('confirmado...', G, 0.22)
        _step('buscando em fontes...', B, 0.32)
        _step('busca completa ✅', G, 0.28)
        print()
        _type_line(f'{Y}Resultado:{R}', 0.025)
        print(f'{DIM}(baseado em fontes, não garante confirmação){R}')
        print()
        time.sleep(0.12)

    # Agrupa — saída limpa: Dados / X: / Y:
    groups = {}
    for f in findings:
        key = f.get('platform') or f.get('group') or f.get('type') or 'Geral'
        groups.setdefault(key, []).append(f)

    print(f'{Y}LEGENDA DOS RESULTADOS{R}')
    print(f'  {G}CONFIRMADO{R}: a fonte confirmou apenas o fato descrito (não identidade).')
    print(f'  {B}INFO{R}: informação contextual/validação, sem comprovar existência de conta.')
    print(f'  {Y}INDICIO{R}: sinal compatível, requer verificação manual.')
    print(f'  {Y}INCONCLUSIVO{R}: bloqueio, ausência de resposta ou evidência insuficiente.')
    print(f'  {RED}ERRO{R}: a consulta falhou; não permite concluir positivo ou negativo.')
    print(f'{G}Dados:{R}')
    for gname, items in groups.items():
        print(f'{Y}{gname}:{R}')
        for f in items:
            col = _status_color(f.get('status'))
            st = (f.get('status') or 'info').upper()
            val = str(f.get('value') or '')
            http = f.get('http')
            bit = f' HTTP {http}' if http is not None else ''
            line = f'  {col}●{R} {val}{bit}  {col}{st}{R}'
            if animate:
                _type_line(line, 0.01)
            else:
                print(line)
            src = f.get('source')
            if src and str(src).startswith('http'):
                link = f'      {B}{src}{R}'
                if animate:
                    _type_line(link, 0.005)
                else:
                    print(link)
        print()

def run_module(label, fn, prompt):
    target = input(prompt).strip()
    if not target:
        print(f'{Y}Cancelado.{R}')
        return
    print()
    _step(f'{label}: preparando...', B, 0.2)
    try:
        findings = fn(target)
    except (ValueError, UnicodeError) as exc:
        print(f'{RED}  ✗ Entrada inválida: {exc}{R}')
        return
    except Exception as exc:
        print(f'{RED}  ✗ Falha: {type(exc).__name__}{R}')
        return
    show_findings(findings, animate=True)
    if input(f'\n{DIM}Guardar? [s/N]:{R} ').strip().lower() == 's':
        save_history(findings)
        print(f'{G}  ✓ Salvo ({len(findings)}){R}')

def run_ports():
    host = input('Host autorizado: ').strip()
    if not host:
        print(f'{Y}Cancelado.{R}')
        return
    if input(f'Digite SIM para autorizar {host}: ').strip() != 'SIM':
        print(f'{Y}Cancelado.{R}')
        return
    print()
    _step('autorização ok', G, 0.2)
    _step(f'scan TCP ({len(COMMON_PORTS)} portas)...', Y, 0.3)
    try:
        findings = scan_ports(host)
    except (ValueError, UnicodeError) as exc:
        print(f'{RED}  ✗ {exc}{R}')
        return
    show_findings(findings, animate=True)
    if input(f'\n{DIM}Guardar? [s/N]:{R} ').strip().lower() == 's':
        save_history(findings)
        print(f'{G}  ✓ Salvo ({len(findings)}){R}')

def show_history():
    items=load_history()
    if not items: print('Ainda não há resultados salvos.'); return
    show_findings(items[-100:], animate=False)
    # Correlação simples e transparente por valores iguais; não afirma identidade.
    groups={}
    for f in items:
        value=str(f.get('value','')).strip().lower()
        if value: groups.setdefault(value,[]).append(f)
    matches=[(v,fs) for v,fs in groups.items() if len(fs)>1]
    print('\n=== Correlações simples por valor idêntico ===')
    if not matches: print('Nenhum valor repetido encontrado no histórico.')
    for value,fs in matches:
        print(f'- {value}: {len(fs)} ocorrências em '+', '.join(sorted({x.get('module','módulo') for x in fs})))
    print('A coincidência de valores não comprova que duas contas ou registros pertençam à mesma pessoa.')

def main():
    while True:
        print('\033[2J\033[H', end='')
        print_banner()
        print(f'{Y} MENU PRINCIPAL{R}')
        for n, name, desc in MENU:
            print(f' {G}{n:>2}.{R} {W}{name:<15}{R} {B}- {desc}{R}')
        print(f' {G} 0.{R} Sair')
        choice = input(f'\n{Y}Escolha uma opção:{R} ').strip()
        if choice=='1': run_module('E-mail',check_email,'E-mail: ')
        elif choice=='2': run_module('Busca de username',lookup_username,'Username (sem @): ')
        elif choice=='3': run_module('Telefone',check_phone,'Telefone (com DDI se souber): ')
        elif choice=='4': run_module('DNS',dns_lookup,'Domínio (ex.: example.com): ')
        elif choice=='5': run_module('HTTP(S)',check_url,'Domínio/URL (ex.: https://example.com): ')
        elif choice=='6': run_module('IP público',lookup_ip,'IP público: ')
        elif choice=='7': run_ports()
        elif choice=='8': run_module('Análise de arquivo',analyze_file,'Caminho local do arquivo: ')
        elif choice=='9': show_history()
        elif choice=='10':
            items=load_history()
            if not items: print('Não há resultados salvos para exportar.')
            else:
                default=ROOT/'data'/'resultados-exportados.json'
                dest=input(f'Caminho do arquivo [{default}]: ').strip() or str(default)
                try:
                    Path(dest).expanduser().parent.mkdir(parents=True,exist_ok=True)
                    Path(dest).expanduser().write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
                    print('Exportado para: '+str(Path(dest).expanduser()))
                except OSError as exc: print(f'Falha ao exportar: {exc}')
        elif choice=='11':
            print('Cole texto/log/HTML para extrair e-mails, IPs, URLs, telefones, hashes, CPF/CNPJ (formato).')
            print('Finalize com uma linha contendo apenas END')
            lines=[]
            while True:
                line=input()
                if line.strip()=='END': break
                lines.append(line)
            text='\n'.join(lines)
            try: findings=extract_from_text(text)
            except Exception as exc:
                print(f'Falha: {exc}'); findings=[]
            show_findings(findings)
            if findings and input('\nGuardar resultados localmente? [s/N]: ').strip().lower()=='s':
                save_history(findings); print(f'{len(findings)} resultado(s) guardado(s).')
        elif choice=='12':
            print('\nDNS: DNS-over-HTTPS público. HTTP: status/cabeçalhos, sem executar scripts.')
            print('Username: 74+ URLs públicas cadastradas; HTTP não confirma identidade e pode haver falsos positivos.')
            print('E-mail: formato + MX + catálogo de serviços; links de recuperação não confirmam existência de contas.')
            print('Extrator Intel: padrões em texto local.')
            print('Portas: até 100 portas TCP por execução; exige digitar SIM e autorização do proprietário. Estados fechados/filtrados podem ser inconclusivos.')
            print('Histórico: data/resultados.json')
        elif choice=='0': print('Encerrando pw OSINT BR.'); break
        else: print('Opção inválida.')
        input('\nEnter para voltar ao menu...')
