"""Armazenamento SQLite e contratos compatíveis com a V1 web."""
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / 'data'
DB_PATH = DATA_DIR / 'osintbr.sqlite3'


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')


def new_id(prefix):
    return f'{prefix}_{uuid.uuid4().hex[:12]}'


def connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    conn.executescript('''
      CREATE TABLE IF NOT EXISTS investigations (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL, notes TEXT NOT NULL DEFAULT ''
      );
      CREATE TABLE IF NOT EXISTS findings (
        id TEXT PRIMARY KEY, investigation_id TEXT NOT NULL,
        type TEXT NOT NULL, value TEXT NOT NULL, detail TEXT NOT NULL,
        status TEXT NOT NULL, module TEXT NOT NULL, ts TEXT NOT NULL,
        source TEXT, confidence TEXT,
        FOREIGN KEY(investigation_id) REFERENCES investigations(id) ON DELETE CASCADE
      );
    ''')
    conn.commit()
    return conn


def create_investigation(name):
    conn = connect()
    ts = now_iso()
    ident = new_id('i')
    conn.execute('INSERT INTO investigations(id,name,createdAt,updatedAt,notes) VALUES(?,?,?,?,?)',
                 (ident, name.strip() or 'Investigação sem nome', ts, ts, ''))
    conn.commit(); conn.close()
    return ident


def list_investigations():
    conn = connect()
    rows = conn.execute('SELECT i.*, (SELECT COUNT(*) FROM findings f WHERE f.investigation_id=i.id) AS finding_count FROM investigations i ORDER BY updatedAt DESC').fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_finding(investigation_id, finding):
    required = ('id','type','value','detail','status','module','ts')
    if any(k not in finding for k in required):
        raise ValueError('Finding não contém todos os campos obrigatórios.')
    conn = connect()
    exists = conn.execute('SELECT id FROM investigations WHERE id=?', (investigation_id,)).fetchone()
    if not exists:
        conn.close(); raise ValueError('Investigação não encontrada.')
    conn.execute('''INSERT INTO findings(id,investigation_id,type,value,detail,status,module,ts,source,confidence)
                    VALUES(?,?,?,?,?,?,?,?,?,?)''',
                 (finding['id'], investigation_id, finding['type'], finding['value'], finding['detail'],
                  finding['status'], finding['module'], finding['ts'], finding.get('source'), finding.get('confidence')))
    conn.execute('UPDATE investigations SET updatedAt=? WHERE id=?', (now_iso(), investigation_id))
    conn.commit(); conn.close()


def export_investigation(investigation_id, destination):
    conn = connect()
    row = conn.execute('SELECT * FROM investigations WHERE id=?', (investigation_id,)).fetchone()
    if not row:
        conn.close(); raise ValueError('Investigação não encontrada.')
    investigation = dict(row)
    findings = conn.execute('SELECT id,type,value,detail,status,module,ts,source,confidence FROM findings WHERE investigation_id=? ORDER BY ts', (investigation_id,)).fetchall()
    conn.close()
    investigation['findings'] = [dict(r) for r in findings]
    Path(destination).write_text(json.dumps(investigation, ensure_ascii=False, indent=2), encoding='utf-8')
    return destination


def list_findings(investigation_id):
    conn = connect()
    rows = conn.execute('SELECT id,type,value,detail,status,module,ts,source,confidence FROM findings WHERE investigation_id=? ORDER BY ts DESC', (investigation_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
