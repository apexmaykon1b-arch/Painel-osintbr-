"""Metadados básicos e hashes locais; não modifica o arquivo."""
import hashlib, os, mimetypes
from pathlib import Path
from ..store import new_id, now_iso

def analyze_file(path):
    p=Path(path).expanduser()
    if not p.is_file(): raise ValueError('O caminho não aponta para um arquivo acessível.')
    h=hashlib.sha256(); size=0
    with p.open('rb') as f:
        while True:
            block=f.read(1024*1024)
            if not block: break
            size+=len(block); h.update(block)
    details=f'Nome: {p.name}; tamanho: {size} bytes; MIME estimado: {mimetypes.guess_type(p.name)[0] or "desconhecido"}; SHA-256: {h.hexdigest()}; extensão: {p.suffix or "sem extensão"}.'
    return [{'id':new_id('f'),'type':'file','value':str(p.resolve()),'detail':details,'status':'confirmado','module':'file_analysis','ts':now_iso(),'source':'metadados e hash calculados localmente','confidence':'Alta para tamanho/hash observados; MIME é estimativa pela extensão.'}]
