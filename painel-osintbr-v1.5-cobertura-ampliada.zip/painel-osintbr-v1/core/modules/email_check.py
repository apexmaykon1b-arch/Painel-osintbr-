"""Validação de e-mail + DNS/MX + roteiro estilo Holehe (links públicos, sem login)."""
import re
import urllib.request
import urllib.error
from urllib.parse import quote
from .dns_lookup import lookup
from ..store import new_id, now_iso

# Sites onde o e-mail pode aparecer em fluxo público de "esqueci senha" / perfil
# (estilo Holehe: indício, não prova de posse da caixa)
HOLEHE_STYLE = {
    "GitHub": "https://github.com/password_reset", "GitLab": "https://gitlab.com/users/password/new", "Reddit": "https://www.reddit.com/password",
    "Adobe": "https://auth.services.adobe.com/en_US/index.html", "Spotify": "https://www.spotify.com/password-reset/", "Pinterest": "https://www.pinterest.com/password/reset/",
    "Tumblr": "https://www.tumblr.com/forgot_password", "WordPress.com": "https://wordpress.com/wp-login.php?action=lostpassword", "Proton": "https://account.proton.me/reset-password",
    "Mozilla": "https://accounts.firefox.com/reset_password", "Instagram": "https://www.instagram.com/accounts/password/reset/", "TikTok": "https://www.tiktok.com/login/phone-or-email/email",
    "Facebook": "https://www.facebook.com/login/identify/", "X": "https://x.com/account/begin_password_reset", "LinkedIn": "https://www.linkedin.com/uas/request-password-reset",
    "Microsoft": "https://account.live.com/password/reset", "Google": "https://accounts.google.com/signin/recovery", "Apple": "https://iforgot.apple.com/",
    "Amazon": "https://www.amazon.com/ap/forgotpassword", "eBay": "https://signin.ebay.com/ws/eBayISAPI.dll?ForgotYourPassword", "Yahoo": "https://login.yahoo.com/forgot",
    "Outlook": "https://account.live.com/password/reset", "Discord": "https://discord.com/login", "Telegram": "https://telegram.org/faq",
    "Snapchat": "https://accounts.snapchat.com/accounts/password_reset_request", "Pinterest Business": "https://www.pinterest.com/password/reset/", "Twitch": "https://www.twitch.tv/user/account-recovery",
    "YouTube/Google": "https://accounts.google.com/signin/recovery", "Steam": "https://help.steampowered.com/en/wizard/HelpWithLogin", "Epic Games": "https://www.epicgames.com/id/login/forgot-password",
    "Roblox": "https://www.roblox.com/login/forgot-password-or-username", "PlayStation": "https://www.playstation.com/support/account/password-reset-psn/", "Xbox/Microsoft": "https://account.live.com/password/reset",
    "Nintendo": "https://accounts.nintendo.com/", "Spotify for Artists": "https://support.spotify.com/", "SoundCloud": "https://soundcloud.com/forgot",
    "Bandcamp": "https://bandcamp.com/forgot_password", "Deezer": "https://www.deezer.com/password/reset", "Last.fm": "https://www.last.fm/login/forgotpassword",
    "Medium": "https://medium.com/m/signin", "Substack": "https://substack.com/sign-in", "Wattpad": "https://www.wattpad.com/forgot_password",
    "Goodreads/Amazon": "https://www.goodreads.com/user/forgot_password", "Letterboxd": "https://letterboxd.com/accounts/password/reset/", "Flickr": "https://identity.flickr.com/",
    "Vimeo": "https://vimeo.com/log_in", "Behance/Adobe": "https://www.behance.net/", "Dribbble": "https://dribbble.com/session/new", "DeviantArt": "https://www.deviantartsupport.com/",
    "ArtStation": "https://www.artstation.com/users/sign_in", "ResearchGate": "https://www.researchgate.net/login", "ORCID": "https://orcid.org/signin", "Google Scholar": "https://scholar.google.com/",
    "Kaggle": "https://www.kaggle.com/account/login", "Hugging Face": "https://huggingface.co/login", "Docker Hub": "https://hub.docker.com/login", "npm": "https://www.npmjs.com/login",
    "PyPI": "https://pypi.org/account/login/", "Bitbucket": "https://bitbucket.org/account/signin/", "Atlassian": "https://id.atlassian.com/login", "Cloudflare": "https://dash.cloudflare.com/login",
    "Canva": "https://www.canva.com/login/", "Figma": "https://www.figma.com/login", "Notion": "https://www.notion.so/login", "Trello/Atlassian": "https://id.atlassian.com/login",
    "Slack": "https://slack.com/signin", "Zoom": "https://zoom.us/signin", "Dropbox": "https://www.dropbox.com/forgot", "Box": "https://account.box.com/login",
    "GitHub Education": "https://github.com/password_reset", "Google Classroom": "https://accounts.google.com/signin/recovery", "Coursera": "https://www.coursera.org/", "Khan Academy": "https://www.khanacademy.org/login",
    "Duolingo": "https://www.duolingo.com/", "Strava": "https://www.strava.com/login", "Komoot": "https://www.komoot.com/login", "Mastodon": "https://joinmastodon.org/",
    "Bluesky": "https://bsky.app/", "Threads": "https://www.threads.net/login", "Linktree": "https://linktr.ee/login", "Gravatar/WordPress": "https://wordpress.com/log-in",
    "Proton Mail": "https://account.proton.me/reset-password", "Fastmail": "https://www.fastmail.com/login/", "Zoho": "https://accounts.zoho.com/signin", "Tutanota/Tuta": "https://app.tuta.com/",
}


def check_email(email, probe_sites=False, timeout=5):
    email = email.strip()
    if len(email) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise ValueError("Formato de e-mail inválido. Exemplo: pessoa@example.com")
    local, domain = email.rsplit("@", 1)
    results = [
        {
            "id": new_id("f"),
            "type": "email",
            "value": email,
            "detail": "Sintaxe válida. Não confirma existência da caixa postal.",
            "status": "info",
            "module": "email_check",
            "ts": now_iso(),
            "source": "validação local",
            "confidence": "Apenas formato.",
            "group": "validacao",
        }
    ]
    try:
        mx = lookup(domain, ["MX"])
        for f in mx:
            f["type"] = "email"
            f["value"] = email
            f["module"] = "email_check"
            f["group"] = "dns"
            f["detail"] = "Domínio — " + f.get("detail", "")
        results.extend(mx)
    except Exception as e:
        results.append(
            {
                "id": new_id("f"),
                "type": "email",
                "value": email,
                "detail": f"Consulta MX não concluída: {type(e).__name__}.",
                "status": "erro",
                "module": "email_check",
                "ts": now_iso(),
                "source": None,
                "confidence": "DNS indisponível.",
                "group": "dns",
            }
        )

    # Roteiro Holehe-like (sempre lista; probe opcional só testa se a página de reset responde)
    for site, url in HOLEHE_STYLE.items():
        detail = (
            f"{site}: abra o fluxo público de recuperação e observe se o serviço "
            f"reconhece o endereço (mensagem genérica ≠ conta existente). URL: {url}"
        )
        status = "info"
        if probe_sites:
            try:
                req = urllib.request.Request(
                    url,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; OSINTBR/1.1)"},
                )
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    detail = f"{site}: página de recuperação respondeu HTTP {r.status}. Verifique manualmente se o e-mail é aceito. {url}"
                    status = "indicio"
            except Exception as e:
                detail = f"{site}: não foi possível abrir a página ({type(e).__name__}). {url}"
                status = "inconclusivo"
        results.append(
            {
                "id": new_id("f"),
                "type": "email_site",
                "value": email,
                "detail": detail,
                "status": status,
                "module": "email_check",
                "ts": now_iso(),
                "source": url,
                "platform": site,
                "confidence": "Baixa — Holehe real usa APIs específicas; aqui é roteiro + indício.",
                "group": "holehe_style",
            }
        )
    return results
