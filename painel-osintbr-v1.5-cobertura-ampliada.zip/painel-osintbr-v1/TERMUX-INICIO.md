# pw 🔎 Painel OSINT BR — instalação e uso no Termux

## 1. Instalar Python
Execute um comando por vez:

```bash
pkg update
pkg install python unzip
```

## 2. Extrair o ZIP
Se o ZIP estiver em Downloads:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip painel-osintbr-v1-python-core-final.zip -d osintbr-final
cd osintbr-final/painel-osintbr-v1
```

Use o nome real do arquivo ZIP que baixou. Se já extraiu o projeto, entre diretamente na pasta que contém `main.py` e `core/`.

## 3. Iniciar

```bash
python main.py
```

Não precisa instalar dependências com `pip`. O banco SQLite é criado automaticamente em `data/osintbr.sqlite3`.

## 4. Primeiro uso
1. Digite `1` e crie uma investigação.
2. Escolha um módulo: `3` DNS, `4` HTTP(S), `5` username, `6` e-mail/MX, `7` telefone, `8` IP público, `9` portas TCP ou `10` arquivo/hash.
3. Quando o programa pedir, selecione a investigação em que quer salvar os resultados.
4. Leia fonte, status e limitações de cada resultado antes de salvar.
5. Use `11` para ver descobertas e `12` para exportar JSON.

## 5. Módulos e limitações
- **DNS:** registros A, AAAA, MX, NS, TXT e CNAME via serviço DNS-over-HTTPS público.
- **HTTP(S):** status e cabeçalhos selecionados; não executa JavaScript.
- **Username:** tenta abrir URLs públicas em plataformas selecionadas. HTTP 200 não prova que o perfil exista ou pertença a alguém; confirme manualmente.
- **E-mail:** verifica formato e MX do domínio; não confirma que a caixa postal exista.
- **Telefone:** normalização local, sem titular/operadora.
- **IP:** consulta dados públicos de IP global usando ipapi.co. Geolocalização é aproximada; exige internet.
- **Portas TCP:** testa uma lista curta de portas comuns. É obrigatório confirmar autorização digitando `SIM`. Use apenas em alvos próprios ou autorizados.
- **Arquivo:** calcula SHA-256 e apresenta metadados locais sem executar ou modificar o arquivo.

## 6. Status
`confirmado` significa que o dado descrito foi observado; não confirma interpretações adicionais. `info` é informativo. `inconclusivo` indica que não há evidência suficiente. `erro` indica falha da operação. Ausência de resposta não prova inexistência.

## 7. Dados e compatibilidade
- SQLite: `data/osintbr.sqlite3`
- Exportações: `exports/`
- A interface web continua usando `localStorage` com a chave `osintbr_v1`.
- O banco Python e o armazenamento do navegador ainda são separados; não há sincronização automática nesta versão.

Não publique exportações com informações sensíveis. Para executar consultas online, o aparelho precisa de conexão à internet.

## 8. Testes locais
Na raiz do projeto:

```bash
python -m unittest discover -s tests -v
```

## 9. Solução de problemas
- `python: command not found`: `pkg install python`.
- `main.py` não encontrado: execute `pwd` e `ls -la`; entre na pasta que contém `main.py` e `core/`.
- Timeout: verifique a internet e tente novamente. O erro não prova que o alvo inexista.
