"""Consulta HTTP(S) real, sem executar conteúdo da página."""
import urllib.error
import urllib.request
from urllib.parse import urlparse
from ..store import new_id, now_iso

SAFE_HEADERS = ('server','content-type','content-length','date','last-modified','location','strict-transport-security',
                'content-security-policy','x-content-type-options','x-frame-options','referrer-policy','permissions-policy')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def check_url(raw_url, timeout=10):
    url = raw_url.strip()
    if '://' not in url:
        url = 'https://' + url
    parsed = urlparse(url)
    if parsed.scheme not in ('http','https') or not parsed.hostname:
        raise ValueError('Informe um domínio ou URL HTTP/HTTPS válida.')
    # HEAD avoids downloading page bodies; GET fallback is limited to headers and a tiny read.
    opener = urllib.request.build_opener(NoRedirect())
    headers = {'User-Agent':'PainelOSINTBR/1.0 (consulta técnica; sem execução de conteúdo)', 'Accept':'*/*'}
    req = urllib.request.Request(url, headers=headers, method='HEAD')
    try:
        response = opener.open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        response = exc
    except Exception as head_error:
        # Some servers reject HEAD; retry GET but do not consume the response body.
        try:
            req = urllib.request.Request(url, headers=headers, method='GET')
            response = opener.open(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            response = exc
        except Exception as get_error:
            return [_finding(url, 'inconclusivo', f'Não foi possível obter resposta HTTP: {type(get_error).__name__}: {get_error}. A tentativa HEAD também falhou: {type(head_error).__name__}.', None, 'Nenhuma conclusão sobre segurança ou existência do site.')]
    try:
        status_code = getattr(response, 'status', None) or getattr(response, 'code', None) or 'desconhecido'
        headers_out = response.headers
        findings = [_finding(url, 'confirmado', f'O servidor respondeu com status HTTP {status_code}.', str(status_code), 'Confirma apenas a resposta observada neste momento; não comprova que o site seja seguro.')]
        for key in SAFE_HEADERS:
            val = headers_out.get(key)
            if val:
                findings.append(_finding(url, 'confirmado', f'Cabeçalho {key}: {val}', val, 'Cabeçalho observado na resposta; interpretação depende do contexto.'))
        return findings
    finally:
        try: response.close()
        except Exception: pass


def _finding(url, status, detail, value, confidence):
    return {'id':new_id('f'), 'type':'domain', 'value':url, 'detail':detail, 'status':status,
            'module':'http_check', 'ts':now_iso(), 'source':url, 'confidence':confidence}
