"""Normalização local de telefone, sem atribuição de titular."""
import re
from ..store import new_id, now_iso

def check_phone(raw, country_code='55'):
    digits=re.sub(r'\D','',raw)
    if not 7 <= len(digits) <= 15: raise ValueError('Informe um telefone com 7 a 15 dígitos, incluindo DDI se conhecido.')
    normalized='+'+digits if raw.strip().startswith('+') else ('+'+digits if digits.startswith(country_code) and len(digits) >= 11 else '+'+country_code+digits)
    return [{'id':new_id('f'),'type':'phone','value':normalized,'detail':f'Número normalizado a partir da entrada {raw!r}. A formatação não confirma que esteja ativo nem identifica titular.','status':'info','module':'phone_check','ts':now_iso(),'source':'normalização local','confidence':'Baixa; sem consulta à operadora.'}]
