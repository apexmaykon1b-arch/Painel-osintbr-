#!/usr/bin/env python3
"""Painel OSINT BR - núcleo local para Termux/Linux (stdlib only)."""
from core.cli import main

if __name__ == '__main__':
    main()
