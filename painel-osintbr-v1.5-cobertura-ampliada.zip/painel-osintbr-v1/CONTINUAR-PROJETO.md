# Painel OSINT BR — Documento para continuação (ChatGPT / IA programadora)

## Identidade do projeto
- **Nome:** Painel OSINT BR
- **Base conceitual:** Mr. Holmes Multi-Framework (documento mestre do usuário)
- **Plataforma atual:** Web (HTML + CSS + JS em arquivo único `index.html`)
- **Idioma:** Português (Brasil)
- **Persistência:** `localStorage` (chave `osintbr_v1`)
- **Filosofia:** poderoso por dentro, simples por fora; **não inventar resultados**; distinguir confirmado / indício / inconclusivo / erro

## O que a V1 web JÁ faz
1. Menu lateral com módulos do documento mestre
2. Modo iniciante / avançado
3. Investigações: criar, abrir, excluir, exportar/importar JSON
4. Salvar descobertas (`findings`) na investigação ativa
5. Pesquisa rápida (heurística de tipo de alvo)
6. Usernames: lista de URLs públicas + tentativa de `fetch` (muitos sites bloqueiam CORS → status “inconclusivo/bloqueado”)
7. E-mail: validação sintática + domínio + roteiro
8. Telefone: normalização de dígitos + roteiro BR
9. Domínio/URL: roteiro + links (crt.sh, whois, dns.google)
10. Dorks: geração de consultas + links Google
11. IP: validação IPv4 + lookup público quando a API permitir CORS
12. Arquivos: metadados básicos no navegador
13. Threat intel: roteiro (sem envio automático do indicador)
14. Correlação: lista findings (sem fusão automática de identidades)
15. Relatório texto + copiar
16. Notas da investigação
17. Central de ferramentas / ajuda / config

## Limitações honestas da V1 web
- Navegador **não** substitui Sherlock completo (CORS).
- DNS/whois profundos no cliente são limitados; muitos usam links manuais.
- Sem backend: sem chaves secretas de API no servidor.
- Pentest real (scan de portas, exploração) **não** deve ser simulado como sucesso falso.
- Forense profunda (EXIF completo, carving) exige WASM/libs ou Termux — marcar como “parcial”.

## Arquitetura alvo (próximas fases)
```
painel-osintbr/
  index.html          # UI web V1 (atual)
  CONTINUAR-PROJETO.md
  (futuro)
  core/               # Python (Termux/Linux)
  modules/
  integrations/
  api/                # opcional FastAPI local
```

### Contrato de finding (já usado no JS)
```json
{
  "id": "f_...",
  "type": "username|email|phone|domain|ip|note|...",
  "value": "string",
  "detail": "string",
  "status": "confirmado|indicio|inconclusivo|info|erro",
  "module": "string",
  "ts": "ISO-8601",
  "source": "string opcional",
  "confidence": "string opcional"
}
```

### Contrato de investigação
```json
{
  "id": "i_...",
  "name": "string",
  "createdAt": "ISO",
  "updatedAt": "ISO",
  "notes": "string",
  "findings": []
}
```

## Princípios obrigatórios (não violar)
1. Não afirmar perfil/vuln/identidade sem evidência da fonte
2. “Não encontrado” ≠ “não existe”
3. APIs pagas só opcionais; explicar como configurar
4. Chaves nunca em relatório exportado publicamente
5. Operações sensíveis: confirmação explícita
6. Pentest: só alvo próprio/autorizado (aviso na UI)

## Backlog prioritário para a próxima IA
### P0 — curto prazo
- [ ] Melhorar checagem de username (proxy local Termux ou lista de sites que permitem CORS)
- [ ] Fetch de headers HTTP via pequeno backend local (CORS)
- [ ] DNS lookup via API pública documentada ou backend
- [ ] UI mobile mais compacta
- [ ] Busca nas findings

### P1 — médio
- [ ] Núcleo Python no Termux espelhando os mesmos módulos
- [ ] Export PDF do relatório
- [ ] Módulo forense com lib JS (EXIF) quando possível
- [ ] Integração opcional com painéis HackinBR (Graph, Dorks, Intel) via links + JSON

### P2 — longo
- [ ] Painel web local servido pelo core Python
- [ ] Filas de tarefas e logs técnicos
- [ ] Testes automatizados dos validadores

## Como estender um módulo (web)
1. Adicionar botão no `#nav` e `section#v-...`
2. Implementar handler que **explica limitações**
3. Produzir texto em `.out` com horário e método
4. `addFinding(...)` ao salvar
5. Atualizar este arquivo e a Central de ferramentas

## Stack atual
- HTML5 + CSS3 + JavaScript vanilla (sem build)
- Sem frameworks
- Compatível com abertura direta do `index.html` e com hospedagem estática (Vercel/Netlify)

## Critério de “completo” (documento mestre)
Só considerar framework completo quando existirem: projetos, findings padronizados, relatórios, ajuda contextual, módulos de identidade/e-mail/domínio/IP/arquivos, correlação transparente, e caminho Termux/Linux — **web V1 é a fatia interface + organização + roteiros + lookups leves**.

## Mensagem ao continuar o código
Preserve a chave `localStorage` `osintbr_v1` ou migre com versionamento (`osintbr_v2`) e importação da v1. Não remova avisos legais/éticos. Prefira melhorar módulos existentes a criar botões vazios.

## Atualização — núcleo Python inicial

Foi adicionada uma primeira implementação do núcleo local:
- `main.py` inicia o menu de terminal.
- `core/store.py` implementa SQLite, investigações, findings e exportação JSON.
- `core/modules/dns_lookup.py` consulta registros A, AAAA, MX, NS, TXT e CNAME por DNS-over-HTTPS público.
- `core/modules/http_check.py` consulta status HTTP(S) e cabeçalhos selecionados, sem executar o conteúdo da página.
- `TERMUX-INICIO.md` documenta instalação e uso no Termux.
- `tests/test_contract.py` testa o contrato básico de findings e armazenamento.

A implementação preserva os campos do contrato de finding da V1 web e os campos principais da investigação. O banco SQLite Python é separado do `localStorage osintbr_v1`; sincronização não está implementada e não deve ser presumida.

### Próximos passos sugeridos
1. Testar manualmente DNS e HTTP em Termux com conexão real.
2. Adicionar testes de validação de domínio/URL e tratamento de falhas de rede.
3. Criar exportação/importação JSON compatível com investigações da V1 web, sem sobrescrever dados silenciosamente.
4. Implementar consulta de IP e e-mail com fontes claramente identificadas.
5. Só depois criar uma API local opcional para o painel web.

Os módulos de pentest, varredura de portas, Sherlock, Holehe, Nuclei e sincronização ainda não estão implementados nesta etapa.

## Estado atualizado do núcleo Python (entrega final ampliada)
Implementado em `core/modules/`: `dns_lookup.py`, `http_check.py`, `username_lookup.py`, `email_check.py`, `phone_check.py`, `ip_lookup.py`, `port_scan.py` e `file_analysis.py`. O menu de `core/cli.py` permite criar/listar investigações, executar os módulos, salvar descobertas com o contrato padronizado, listar findings e exportar JSON. A base permanece SQLite local e o armazenamento web permanece `localStorage osintbr_v1`; não existe sincronização automática entre os dois.

O scanner de portas é deliberadamente limitado a portas TCP comuns, máximo de 30 portas por chamada, timeout curto e confirmação de autorização na interface CLI. Não faz exploração ou brute force. O módulo username apenas verifica URLs públicas e classifica respostas com cautela; HTTP 200 não é tratado como prova de perfil ou identidade. E-mail verifica formato e DNS/MX, sem validar caixa postal. IP usa fonte pública e localização aproximada. Arquivos são lidos apenas para calcular hash/metadados, sem execução ou modificação.

Testes automatizados atuais: `python -m unittest discover -s tests -v`. Consultas de rede reais dependem da conexão do dispositivo e podem falhar por timeout, bloqueios ou limites de serviço.


## Atualização de cobertura v1.4+
- Catálogo ampliado de username com redes sociais, comunicação, estudo/trabalho, comunidades e plataformas de desenvolvimento. Catálogo de URLs não equivale a confirmação de perfil.
- Catálogo de serviços de e-mail aponta somente para páginas oficiais de ajuda/login/recuperação; não automatiza tentativa de recuperação nem afirma existência de contas.
- Scanner TCP usa 100 portas selecionadas por padrão e requer confirmação explícita no CLI.
- Legenda de status é mostrada antes dos resultados; `index.html`, chave `localStorage osintbr_v1` e contratos de findings foram preservados.
