"""Consultas DNS via DNS-over-HTTPS público do Google; sem dependências externas."""
import json
import urllib.parse
import urllib.request
from datetime import datetime
from ..store import new_id, now_iso

ENDPOINT = 'https://dns.google/resolve'
TYPES = {'A': 1, 'AAAA': 28, 'MX': 15, 'TXT': 16, 'NS': 2, 'CNAME': 5}


def lookup(domain, record_types=None, timeout=8):
    domain = domain.strip().rstrip('.').encode('idna').decode('ascii')
    if not domain or '/' in domain or ' ' in domain:
        raise ValueError('Informe somente um domínio, por exemplo: exemplo.com')
    record_types = record_types or ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME']
    results = []
    for rtype in record_types:
        params = urllib.parse.urlencode({'name': domain, 'type': rtype})
        req = urllib.request.Request(f'{ENDPOINT}?{params}', headers={'User-Agent':'PainelOSINTBR/1.0', 'Accept':'application/dns-json'})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                payload = json.loads(response.read(1024 * 1024).decode('utf-8'))
            answers = payload.get('Answer') or []
            if answers:
                for answer in answers:
                    data = str(answer.get('data', '')).rstrip('.') + ('.' if str(answer.get('data', '')).endswith('.') else '')
                    results.append(_finding(domain, rtype, data, f'Registro DNS {rtype}; TTL informado: {answer.get("TTL", "desconhecido")}.', 'confirmado', 'https://dns.google/resolve', 'Alta: resposta retornada pelo resolvedor DNS-over-HTTPS.'))
            else:
                status = 'inconclusivo' if payload.get('Status') not in (0, 3) else 'info'
                explanation = 'A fonte não retornou registros deste tipo.' if payload.get('Status') == 0 else f'Código DNS retornado: {payload.get("Status", "desconhecido")}; isso não prova que o domínio não exista.'
                results.append(_finding(domain, rtype, '(sem resposta)', explanation, status, 'https://dns.google/resolve', 'Limitada: resultado depende do resolvedor consultado.'))
        except Exception as exc:
            results.append(_finding(domain, rtype, '(consulta falhou)', f'Não foi possível consultar DNS {rtype}: {type(exc).__name__}: {exc}', 'erro', ENDPOINT, 'Nenhuma conclusão sobre a existência do registro.'))
    return results


def _finding(domain, rtype, value, detail, status, source, confidence):
    return {'id':new_id('f'), 'type':'domain', 'value':domain, 'detail':f'{rtype}: {value}. {detail}', 'status':status,
            'module':'dns_lookup', 'ts':now_iso(), 'source':source, 'confidence':confidence}
