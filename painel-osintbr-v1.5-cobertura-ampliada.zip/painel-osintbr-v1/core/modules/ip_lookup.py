"""Consulta opcional de dados públicos de IP via ipapi.co."""
import json, ipaddress, urllib.request
from ..store import new_id, now_iso

def lookup_ip(raw, timeout=8):
    try: ip=ipaddress.ip_address(raw.strip())
    except ValueError: raise ValueError('Informe um endereço IPv4 ou IPv6 válido.')
    if not ip.is_global: raise ValueError('Por privacidade, esta consulta externa aceita apenas IPs públicos globais.')
    url=f'https://ipapi.co/{ip}/json/'
    req=urllib.request.Request(url,headers={'User-Agent':'PainelOSINTBR/1.0','Accept':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r: data=json.loads(r.read(128*1024).decode('utf-8'))
    except Exception as e:
        return [{'id':new_id('f'),'type':'ip','value':str(ip),'detail':f'Consulta externa falhou: {type(e).__name__}: {e}','status':'erro','module':'ip_lookup','ts':now_iso(),'source':url,'confidence':'Sem conclusão.'}]
    if data.get('error'): detail='Fonte retornou erro: '+str(data.get('reason','motivo não informado'))
    else: detail='; '.join(f'{k}: {data.get(k)}' for k in ('ip','version','city','region','country_name','org','asn') if data.get(k)) or 'Fonte não retornou campos informativos.'
    return [{'id':new_id('f'),'type':'ip','value':str(ip),'detail':detail,'status':'confirmado' if not data.get('error') else 'inconclusivo','module':'ip_lookup','ts':now_iso(),'source':url,'confidence':'Geolocalização de IP é aproximada; pode representar provedor/VPN, não endereço de uma pessoa.'}]
