"""Módulos de consultas reais do núcleo."""
