import unittest
from core.modules.email_check import check_email
from core.modules.phone_check import check_phone
from core.modules.file_analysis import analyze_file
from core.modules.port_scan import scan_ports
from core.modules.username_lookup import lookup_username
from core.modules.ip_lookup import lookup_ip

class ModuleTests(unittest.TestCase):
    def test_email_format_rejects_invalid(self):
        with self.assertRaises(ValueError): check_email('not-an-email')
    def test_phone_normalization(self):
        item=check_phone('(11) 99999-0000')[0]
        self.assertEqual(item['type'],'phone')
        self.assertEqual(item['value'],'+5511999990000')
        self.assertIn('status',item)
    def test_file_hash(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b'osintbr-test')
            path=f.name
        try:
            item=analyze_file(path)[0]
            self.assertIn('SHA-256',item['detail'])
            self.assertEqual(item['type'],'file')
        finally: os.unlink(path)
    def test_port_limit(self):
        with self.assertRaises(ValueError): scan_ports('localhost', list(range(1,102)))
    def test_username_validation(self):
        with self.assertRaises(ValueError): lookup_username('invalid name')
    def test_private_ip_rejected(self):
        with self.assertRaises(ValueError): lookup_ip('127.0.0.1')

if __name__=='__main__': unittest.main()
