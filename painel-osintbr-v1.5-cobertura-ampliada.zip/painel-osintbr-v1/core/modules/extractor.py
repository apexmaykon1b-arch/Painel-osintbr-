"""Extrator estilo Intel: e-mails, IPs, URLs, telefones, hashes, CPF/CNPJ (formato)."""
import re
from ..store import new_id, now_iso

RE_EMAIL = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}")
RE_IP = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b")
RE_URL = re.compile(r"https?://[^\s<>\"']+")
RE_PHONE = re.compile(r"(?:\+?55\s?)?(?:\(?\d{2}\)?\s?)?(?:9\s?)?\d{4}[-\s]?\d{4}")
RE_HASH32 = re.compile(r"\b[a-fA-F0-9]{32}\b")
RE_HASH40 = re.compile(r"\b[a-fA-F0-9]{40}\b")
RE_HASH64 = re.compile(r"\b[a-fA-F0-9]{64}\b")
RE_CPF = re.compile(r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b")
RE_CNPJ = re.compile(r"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b")


def extract_from_text(text: str):
    text = text or ""
    groups = {
        "email": sorted(set(RE_EMAIL.findall(text))),
        "ip": sorted(set(RE_IP.findall(text))),
        "url": sorted(set(RE_URL.findall(text)))[:50],
        "phone": sorted(set(RE_PHONE.findall(text))),
        "hash_md5": sorted(set(RE_HASH32.findall(text))),
        "hash_sha1": sorted(set(RE_HASH40.findall(text))),
        "hash_sha256": sorted(set(RE_HASH64.findall(text))),
        "cpf_formato": sorted(set(RE_CPF.findall(text))),
        "cnpj_formato": sorted(set(RE_CNPJ.findall(text))),
    }
    results = []
    for kind, values in groups.items():
        for v in values:
            results.append(
                {
                    "id": new_id("f"),
                    "type": kind,
                    "value": v,
                    "detail": f"Extraído de texto local ({kind}). Formato apenas — não valida autenticidade.",
                    "status": "info",
                    "module": "extractor",
                    "ts": now_iso(),
                    "source": "texto fornecido pelo usuário",
                    "confidence": "Heurística de padrão.",
                    "group": kind,
                }
            )
    if not results:
        results.append(
            {
                "id": new_id("f"),
                "type": "extractor",
                "value": "(vazio)",
                "detail": "Nenhum padrão reconhecido no texto.",
                "status": "info",
                "module": "extractor",
                "ts": now_iso(),
                "source": "texto fornecido pelo usuário",
                "confidence": "—",
                "group": "summary",
            }
        )
    return results
